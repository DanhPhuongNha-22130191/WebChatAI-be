package com.appchat.backend.repository;

import com.appchat.backend.entity.MessageReaction;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface MessageReactionRepository extends JpaRepository<MessageReaction, Long> {

    List<MessageReaction> findByMessageId(Long messageId);

    Optional<MessageReaction> findByMessageIdAndUsername(Long messageId, String username);

    void deleteByMessageIdAndUsername(Long messageId, String username);
}